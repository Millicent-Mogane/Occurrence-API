
using System.Collections.Generic;

namespace OccurrenceApi.Models
{
    public class OccurrenceRequest
    {
        public List<string> Items { get; set; }
    }
}
